<?php  require_once "indexperfil.php"?>
    <!-- /. NAV SIDE  -->
    <div id="page-wrapper" >
        <div id="page-inner" class="container">


            <div class="ui text container form-sobre-fotos" >
                <div class="ui text container centered aligned">
                    <h1><label><font color="black">Cadastro de Tipo de Produto</font></label></h1>
                </div><br>
                <form class="ui form" action="http://localhost/tcc/app/controllers/cliente1_controller.php?acao=inserir" method="post">

                    <div class="field">
                        <label><font color="#363636">Nome do novo tipo de produto</font></label>
                        <input type="text" name="nome_fantasia" placeholder="Nome do tipo">
                    </div>

                    <button class="ui button" type="submit" style="background-color: #87CEEB;" >Cadastrar</button>
                </form>

            </div>

            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>

<?php require_once "rodape.php"; ?>