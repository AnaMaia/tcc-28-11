
<?php  require_once "indexperfil.php"; ?>

<!-- /. NAV SIDE  -->
<div id="page-wrapper" >
    <div id="page-inner" class="container">

        <a href="cadastrolojas.php" class="ui button" >Cadastrar Novas Lojas <i class="glyphicon glyphicon-plus-sign" style=" margin-left: 5px"></i> </a>


    </div>

</div>



<?php require_once "rodape.php"; ?>


