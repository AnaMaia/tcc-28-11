 <?php require_once "indexperfil.php"; ?>
 <div id="page-wrapper" >
     <div id="page-inner" class="container">

         <div class="col-md-10 col-sm-12" style="margin-left: 88px">
             <div class="panel panel-default">
                 <div class="panel-heading">
                     Notificações
                 </div>
                 <div class="panel-body">
                     <ul class="nav nav-tabs">
                         <li class=""><a href="#home" data-toggle="tab" aria-expanded="false">Pedidos de venda</a>
                         </li>
                         <li class=""><a href="#profile" data-toggle="tab" aria-expanded="false">Produtos em estoque mínimo</a>
                         </li>

                     </ul>
                     <div class="tab-content">
                         <div class="tab-pane fade" id="home">
                             <p>lalala</p>
                         </div>
                         <div class="tab-pane fade" id="profile">
                               <p>lalala</p>
                         </div>

                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>
 <!-- /. PAGE WRAPPER  -->
 </div>


 <?php require_once "rodape.php"; ?>
